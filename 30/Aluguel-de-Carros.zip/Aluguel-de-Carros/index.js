/* 
TEAM:
Ana 
Giulia
Bruno
Nicolas
Adriano
Carlos

Exercicio N 30
12-01-2021

*/


let formCarro = document.querySelector('#formCarro');
let arraycarros = [];

let carro = {
    
    status: false,
    modelo: formCarro.modelo.value,
    placa: formCarro.placa.value,
    
    alugar: function () {
        if (this.status == false) {
            this.status = true;
        } else {
            console.log('Este carro ja foi alugado.');
        }
    },
    devolver: function () {
        if (this.status == true) {
            this.status = false;
            console.log('voce esta devolvendo o carro');
        } else {
            console.log('voce ja devolveu o carro!');
        }
    },
    combustivel: function (km) {
        let gastou = km * 3; //combustivel gasto
        console.log(`voce gastou, ${gastou} Litros de combustivel`)
        console.log(`sua taxa por km percorrigo R$ ${(gastou / 1000) * 100}`)
    }

}

             /* ALUGAR */
formCarro.addEventListener('submit', function () {
    
    event.preventDefault()
    carro.alugar()
    console.log(carro);
    arraycarros.push(carro);
    console.log(arraycarros)

});












/*
carro.alugar()
console.log(carro.status)
carro.devolver()
carro.combustivel(10)
console.log(carro) */